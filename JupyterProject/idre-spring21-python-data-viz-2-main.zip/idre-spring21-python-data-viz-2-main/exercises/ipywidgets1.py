def reverse(x):
    return x[::-1]

ipywidgets.interact(reverse, x='Hello');